namespace TestedApplication.Database
{
    public enum Operations
    {
        Add,
        Sub
    }
}