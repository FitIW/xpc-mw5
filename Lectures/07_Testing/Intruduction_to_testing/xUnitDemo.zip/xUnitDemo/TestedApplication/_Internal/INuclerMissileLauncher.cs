﻿namespace TestedApplication._Internal
{
    public interface IMissileLauncher
    {
        /// <summary>
        /// This method will launch missile.
        /// </summary>
        bool LaunchMissile();
    }
}