﻿namespace TestedApplication._Internal
{
    internal class NuclerMissileLauncher : IMissileLauncher
    {
        /// <summary>
        /// This method will launch nuclear retaliation.
        /// </summary>
        public bool LaunchMissile()
        {
            //SORRY did not feel like implementing this one!
            return true;
        }
    }
}